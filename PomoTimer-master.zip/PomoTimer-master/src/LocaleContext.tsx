import React from "react";

export default React.createContext({
  locale: 'en',
  setLocale: function(lan:string){}
});